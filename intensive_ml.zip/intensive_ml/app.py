import numpy as np
import pandas as pd
import pickle
import json
import os
import time
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.datasets import make_regression
import joblib
import h5py
import logging
from pathlib import Path

# Configuració de logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class DiskIntensiveML:
    def __init__(self, base_dir="ml_data"):
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(exist_ok=True)
        self.models_dir = self.base_dir / "models"
        self.data_dir = self.base_dir / "datasets"
        self.results_dir = self.base_dir / "results"
        
        for directory in [self.models_dir, self.data_dir, self.results_dir]:
            directory.mkdir(exist_ok=True)
        
        logger.info(f"Directori base: {self.base_dir.absolute()}")

    def generate_synthetic_data(self, n_samples=100000, n_features=50, n_informative=25):
        """Genera dades sintètiques per a regressió"""
        logger.info(f"Generant {n_samples} mostres amb {n_features} característiques...")
        
        start_time = time.time()
        X, y = make_regression(
            n_samples=n_samples,
            n_features=n_features,
            n_informative=n_informative,
            noise=0.1,
            random_state=42
        )
        
        # Afegir noms de característiques
        feature_names = [f'feature_{i:03d}' for i in range(n_features)]
        df = pd.DataFrame(X, columns=feature_names)
        df['target'] = y
        
        generation_time = time.time() - start_time
        logger.info(f"Dades generades en {generation_time:.2f} segons")
        
        return df, feature_names

    def save_large_dataset(self, df, filename, chunksize=10000):
        """Desa un dataset gran en múltiples formats"""
        base_name = self.data_dir / filename
        
        logger.info("Desant dataset en múltiples formats...")
        
        # 1. CSV (escriptura seqüencial)
        start_time = time.time()
        csv_path = base_name.with_suffix('.csv')
        df.to_csv(csv_path, index=False)
        csv_time = time.time() - start_time
        logger.info(f"CSV guardat en {csv_time:.2f} segons - Mida: {csv_path.stat().st_size / (1024**2):.2f} MB")

        # 2. Parquet (format eficient)
        start_time = time.time()
        parquet_path = base_name.with_suffix('.parquet')
        df.to_parquet(parquet_path, index=False, compression='snappy')
        parquet_time = time.time() - start_time
        logger.info(f"Parquet guardat en {parquet_time:.2f} segons - Mida: {parquet_path.stat().st_size / (1024**2):.2f} MB")

        # 3. HDF5 (format binari)
        start_time = time.time()
        h5_path = base_name.with_suffix('.h5')
        with h5py.File(h5_path, 'w') as hf:
            hf.create_dataset('features', data=df.drop('target', axis=1).values)
            hf.create_dataset('target', data=df['target'].values)
            hf.attrs['feature_names'] = json.dumps(list(df.drop('target', axis=1).columns))
        h5_time = time.time() - start_time
        logger.info(f"HDF5 guardat en {h5_time:.2f} segons - Mida: {h5_path.stat().st_size / (1024**2):.2f} MB")

        # 4. Pickle (serialització Python)
        start_time = time.time()
        pkl_path = base_name.with_suffix('.pkl')
        with open(pkl_path, 'wb') as f:
            pickle.dump(df, f)
        pkl_time = time.time() - start_time
        logger.info(f"Pickle guardat en {pkl_time:.2f} segons - Mida: {pkl_path.stat().st_size / (1024**2):.2f} MB")

        return {
            'csv': csv_path,
            'parquet': parquet_path,
            'hdf5': h5_path,
            'pickle': pkl_path
        }

    def train_multiple_models(self, X_train, y_train, X_test, y_test, n_models=5):
        """Entrena múltiples models i els desa en disc"""
        logger.info(f"Entrenant {n_models} models...")
        
        models = {}
        performance = {}
        
        for i in range(n_models):
            start_time = time.time()
            
            # Model amb diferents hiperparàmetres
            model = RandomForestRegressor(
                n_estimators=100 + i*20,
                max_depth=10 + i*2,
                random_state=42 + i,
                n_jobs=-1  # Ús intensiu de CPU
            )
            
            model_name = f"random_forest_model_{i:02d}"
            logger.info(f"Entrenant {model_name}...")
            
            model.fit(X_train, y_train)
            
            # Predicció i avaluació
            y_pred = model.predict(X_test)
            mse = mean_squared_error(y_test, y_pred)
            r2 = r2_score(y_test, y_pred)
            
            training_time = time.time() - start_time
            
            # Guardar model
            model_path = self.models_dir / f"{model_name}.joblib"
            joblib.dump(model, model_path)
            
            models[model_name] = {
                'model': model,
                'path': model_path,
                'training_time': training_time,
                'mse': mse,
                'r2': r2
            }
            
            logger.info(f"Model {model_name} - MSE: {mse:.4f}, R²: {r2:.4f}, Temps: {training_time:.2f}s")
        
        return models

    def cross_validation_intensive(self, df, feature_names, n_splits=5):
        """Realitza validació creuada amb ús intensiu de disc"""
        logger.info(f"Realitzant validació creuada amb {n_splits} splits...")
        
        from sklearn.model_selection import KFold
        kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)
        
        cv_results = []
        X = df[feature_names].values
        y = df['target'].values
        
        for fold, (train_idx, val_idx) in enumerate(kf.split(X)):
            logger.info(f"Processant fold {fold + 1}/{n_splits}")
            
            start_time = time.time()
            
            X_train, X_val = X[train_idx], X[val_idx]
            y_train, y_val = y[train_idx], y[val_idx]
            
            # Entrenar model per a aquest fold
            model = RandomForestRegressor(n_estimators=100, random_state=42)
            model.fit(X_train, y_train)
            
            # Predicció
            y_pred = model.predict(X_val)
            mse = mean_squared_error(y_val, y_pred)
            r2 = r2_score(y_val, y_pred)
            
            # Guardar model del fold
            fold_model_path = self.models_dir / f"cv_fold_{fold:02d}.joblib"
            joblib.dump(model, fold_model_path)
            
            # Guardar prediccions
            fold_pred_path = self.results_dir / f"predictions_fold_{fold:02d}.csv"
            pred_df = pd.DataFrame({
                'actual': y_val,
                'predicted': y_pred,
                'fold': fold
            })
            pred_df.to_csv(fold_pred_path, index=False)
            
            fold_time = time.time() - start_time
            
            cv_results.append({
                'fold': fold,
                'mse': mse,
                'r2': r2,
                'model_path': fold_model_path,
                'predictions_path': fold_pred_path,
                'training_time': fold_time
            })
            
            logger.info(f"Fold {fold + 1} completat - MSE: {mse:.4f}, Temps: {fold_time:.2f}s")
        
        return cv_results

    def disk_io_stress_test(self, df, operations=10):
        """Test d'estrès per a operacions de disc"""
        logger.info(f"Iniciant test d'estrès amb {operations} operacions...")
        
        test_dir = self.base_dir / "stress_test"
        test_dir.mkdir(exist_ok=True)
        
        io_times = []
        
        for i in range(operations):
            start_time = time.time()
            
            # Operacions diverses de disc
            temp_file = test_dir / f"temp_operation_{i:04d}.csv"
            
            # Escriptura
            df.sample(frac=0.1).to_csv(temp_file, index=False)
            
            # Lectura
            temp_df = pd.read_csv(temp_file)
            
            # Processament i re-escriptura
            temp_df['processed'] = temp_df.iloc[:, 0] * 2
            temp_df.to_csv(temp_file, index=False)
            
            # Serialització addicional
            pkl_file = test_dir / f"temp_pickle_{i:04d}.pkl"
            with open(pkl_file, 'wb') as f:
                pickle.dump(temp_df, f)
            
            operation_time = time.time() - start_time
            io_times.append(operation_time)
            
            if (i + 1) % 5 == 0:
                logger.info(f"Operació {i + 1}/{operations} completada en {operation_time:.2f}s")
        
        # Neteja de fitxers temporals
        for temp_file in test_dir.glob("temp_*"):
            temp_file.unlink()
        test_dir.rmdir()
        
        return io_times

    def run_complete_pipeline(self, n_samples=50000, n_features=30):
        """Executa el pipeline complet d'ML amb ús intensiu de disc"""
        logger.info("Iniciant pipeline complet...")
        
        # 1. Generar dades
        df, feature_names = self.generate_synthetic_data(n_samples, n_features)
        
        # 2. Guardar dades en múltiples formats
        file_paths = self.save_large_dataset(df, "synthetic_dataset")
        
        # 3. Preparar dades per a entrenament
        X = df[feature_names].values
        y = df['target'].values
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )
        
        # 4. Entrenar múltiples models
        models = self.train_multiple_models(X_train, y_train, X_test, y_test, n_models=3)
        
        # 5. Validació creuada
        cv_results = self.cross_validation_intensive(df, feature_names, n_splits=3)
        
        # 6. Test d'estrès de disc
        io_times = self.disk_io_stress_test(df, operations=5)
        
        # 7. Guardar resultats finals
        results = {
            'dataset_info': {
                'n_samples': n_samples,
                'n_features': n_features,
                'file_sizes': {k: v.stat().st_size for k, v in file_paths.items()}
            },
            'model_performance': {
                name: {k: v for k, v in info.items() if k != 'model'} 
                for name, info in models.items()
            },
            'cv_results': cv_results,
            'io_performance': {
                'avg_io_time': np.mean(io_times),
                'total_operations': len(io_times),
                'all_io_times': io_times
            }
        }
        
        results_path = self.results_dir / "final_results.json"
        with open(results_path, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        logger.info(f"Pipeline completat. Resultats guardats a: {results_path}")
        
        # Estadístiques finals
        total_disk_usage = sum(f.stat().st_size for f in self.base_dir.rglob('*') if f.is_file())
        logger.info(f"Ús total de disc: {total_disk_usage / (1024**2):.2f} MB")
        
        return results

def main():
    """Funció principal"""
    try:
        # Crear instància de l'aplicació
        ml_app = DiskIntensiveML("intensive_ml_project")
        
        # Executar pipeline (ajusta els paràmetres segons les teves necessitats)
        results = ml_app.run_complete_pipeline(
            n_samples=20000,  # Reduït per a prova, augmenta per a més ús de disc
            n_features=20
        )
        
        logger.info("Aplicació executada amb èxit!")
        
    except Exception as e:
        logger.error(f"Error en l'execució: {e}")
        raise

if __name__ == "__main__":
    main()