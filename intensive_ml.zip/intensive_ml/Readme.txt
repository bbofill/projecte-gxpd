Característiques principals d'aquesta aplicació:
Ús Intensiu de Disc:
    Múltiples formats de fitxer: CSV, Parquet, HDF5, Pickle
    Operacions massives d'E/S: Escriptura, lectura, serialització
    Test d'estrès: Múltiples operacions de disc simultànies
    Guardat de models: Cada model i fold es desa individualment

Machine Learning:
    Dades sintètiques: Generació automàtica de datasets grans
    Models: Random Forest amb diferents hiperparàmetres
    Validació creuada: K-Fold cross-validation
    Mètriques: MSE, R² score

Instal·lació i Execució:

# Crear un Venv i instal·lar dependències
python3 -m venv myenv
source source myenv/bin/activate
pip3 install numpy pandas scikit-learn matplotlib h5py pyarrow tables

# Executar l'aplicació
python3 app.py

# Executar visualització
python3 rendiment.py     # Aquesta execució generarà un PNG mínim amb les dades dels models i el temps d'operació per E//S 



L'estudiant ha de fer servir aquesta aplicació com base per:
    Generar grans volums de dades sintètiques per a fer proves (es pot ajustar els paràmetres n_samples i n_features per augmentar o disminuir la càrrega sobre el disc).
    Provar el rendiment del disc dur (RAID, LVM, Gluster)
    Veure com diferents formats de fitxer afecten l'eficiència
    Analitzar el compromís entre ús de disc i rendiment de ML.
