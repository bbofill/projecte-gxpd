# visualitzacio_rendiment.py
import matplotlib.pyplot as plt
import pandas as pd
import json
from pathlib import Path

def visualize_performance(results_dir="intensive_ml_project/results"):
    """Visualitza les mètriques de rendiment del pipeline"""
    results_path = Path(results_dir) / "final_results.json"
    
    with open(results_path, 'r') as f:
        data = json.load(f)
    
    # Crear gràfics
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    
    # Rendiment dels models
    model_names = list(data['model_performance'].keys())
    mse_scores = [data['model_performance'][name]['mse'] for name in model_names]
    r2_scores = [data['model_performance'][name]['r2'] for name in model_names]
    
    axes[0, 0].bar(model_names, mse_scores, color='skyblue')
    axes[0, 0].set_title('MSE per Model')
    axes[0, 0].set_ylabel('Mean Squared Error')
    
    axes[0, 1].bar(model_names, r2_scores, color='lightgreen')
    axes[0, 1].set_title('R² Score per Model')
    axes[0, 1].set_ylabel('R² Score')
    
    # Temps d'E/S
    io_times = data['io_performance']['all_io_times']
    axes[1, 0].plot(range(len(io_times)), io_times, marker='o')
    axes[1, 0].set_title('Temps per Operació d\'E/S')
    axes[1, 0].set_xlabel('Operació')
    axes[1, 0].set_ylabel('Temps (segons)')
    
    # Resultats de validació creuada
    cv_folds = [result['fold'] for result in data['cv_results']]
    cv_mse = [result['mse'] for result in data['cv_results']]
    
    axes[1, 1].bar(cv_folds, cv_mse, color='orange')
    axes[1, 1].set_title('MSE per Fold (Validació Creuada)')
    axes[1, 1].set_xlabel('Fold')
    axes[1, 1].set_ylabel('MSE')
    
    plt.tight_layout()
    plt.savefig('rendiment_ml.png', dpi=300, bbox_inches='tight')
    plt.show()

if __name__ == "__main__":
    visualize_performance()